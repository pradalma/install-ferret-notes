! source file: /home/andreas/models/UVic/2.6/npzd_co2/ctr/updates/species.h
c====================== include file "species.h" ==========================
c
        integer it_dic
        real k0,kk1,k2,kkw,kb,ks,kf,k1p,k2p,k3p,ksi
        real bt,st,ft,sit,pt,dic,ta
        common /const/k0,kk1,k2,kkw,kb,ks,kf,k1p,k2p,k3p,ksi
c,ff,htotal
        common /species/bt,st,ft,sit,pt,dic,ta
        common /dic/it_dic

